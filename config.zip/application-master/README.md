### Проект 2292 
#### Распознавание рукописного текста и формул с маркерных досок

### TODO

Общая архитектура:
```
whiteboard_ocr/
│
├── pipeline/
│   ├── pipeline.py        # ← главный оркестратор, базовый класс приложения
│   ├── preprocessing.py   # нормализация гистограммы, исправление перспективных искажений
│   ├── detection.py       # обнаружение регионов
│   ├── recognition.py     # VLM API
│   ├── postprocessing.py
│
├── configs/
│   └── config.yaml
│
├── ui/
│   └── streamlit_app.py
│
├── cli/
│   └── run_ocr.py
│
└── utils/
    ├── visualization.py   # bbox + overlay
    ├── latex.py           # проверка/рендер
```
#### UI
**Web**
- [ ] Загрузка изображение/фото
- [ ] Предпросмотр результатов детекции регионов 
- [ ] переключение провайдеров/моделей - сейчас нужно хотя бы добавить Ollama/vLLM, модель можно выбирать в конфиге
- [ ] отображение bbox (детекции)
- [ ] отображение распознанного LaTeX
- [ ] сравнение “raw vs processed”

**CLI**
Простой консольный интерфейс:
```bash
python run_ocr.py file.jpg --config configs/config.yaml
```

#### Препроцессинг
Первая очередь
- [ ] detect whiteboard region - SAM3, в перспективе можно дообучить модельку
- [ ] contrast enhancement (CLAHE or histogram equalization)
- [ ] binarize (adaptive threshold) - всё, что выше/ниже определённого порога, закрашивается белым/чёрным
Вторая очередь
- [ ] Lighting normalization - устранение неравномерностей освещения (теоретически - назкочастотным фильтром)
- [ ] perspective transform/dewarping (rectify)
- [ ] convert to grayscale - cv2.cvtColor(image, cv2.COLOR.BGR2GRAY) или аналогичное из PIL
- [ ] denoise - просто проходимся фильтром-свёрткой для сглаживания и удаления высокочастотных шумов


#### Дополнительная функциональность
- [ ] логирование
C помощью Logging, где нужно
- [ ] сохранение промежуточных результатов
Можно в виде временной папки, т.е. хранить все артефкаты конкретного задания ограниченное время.
```
outputs/
    raw/
    preprocessed/
    detections/
    predictions.json
```
- [ ] 