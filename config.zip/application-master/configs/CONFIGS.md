Пример:

```YAML
model:
  provider: google
  name: gemini-2.5-flash

detection:
  model: surya

preprocessing:
  enabled: true
  clahe: true

pipeline:
  use_detection: true
  use_preprocessing: true
```